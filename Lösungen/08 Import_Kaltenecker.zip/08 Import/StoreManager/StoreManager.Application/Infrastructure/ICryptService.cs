﻿namespace StoreManager.Application.Infrastructure
{
    public interface ICryptService
    {
        string GenerateHash(string key, string data);
        string GenerateHash(byte[] key, string data);
        string GenerateHash(byte[] key, byte[] data);
        string GenerateSecret(int bits = 256);
    }
}